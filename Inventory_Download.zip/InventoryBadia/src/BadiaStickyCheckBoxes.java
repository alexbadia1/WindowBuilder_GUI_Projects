import java.util.*;
import javax.swing.JCheckBox;

public class BadiaStickyCheckBoxes {
	
	private ArrayList<JCheckBox> checkedCheckBoxes = new ArrayList<JCheckBox>();
	private String myCategoryButtonState;
	
	public BadiaStickyCheckBoxes () {
		setCategoryButtonState("Category Filter: OFF");
	}//null constructor
	
	public ArrayList<JCheckBox> getCheckedCheckBoxes() {
		return checkedCheckBoxes;
	}//getCheckedCheckBoxes
	
	public boolean isEmpty() {
		return checkedCheckBoxes.isEmpty();
	}//isEmpty
	
	public void add(JCheckBox checkBox) {
		int count = 0;
		boolean found = false;
		while(count < checkedCheckBoxes.size() && found != true) {
			if (checkedCheckBoxes.get(count).getText().trim().equals(checkBox.getText().trim())) {
				found = true;
			} else count++;
		}//while
		if (!found) {checkedCheckBoxes.add(checkBox);}
	}//add
	
	public void removeAll() {
		checkedCheckBoxes.removeAll(checkedCheckBoxes);
		System.out.println(checkedCheckBoxes.size());
	}//removeAll

	public String getCategoryButtonState() {
		return myCategoryButtonState;
	}//getCategoryButtonState

	public void setCategoryButtonState(String newCategoryButtonState) {
		this.myCategoryButtonState = newCategoryButtonState;
	}//setCategoryButtonState
	
}//class
